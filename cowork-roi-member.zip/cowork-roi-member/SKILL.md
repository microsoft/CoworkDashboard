---
name: cowork-roi-member
description: |
  Member step of the team Cowork ROI rollup. Harvests the signed-in user's own Copilot Cowork session history from OneDrive, lets the user exclude any chat/task, computes impact metrics, and posts a de-identified, TABLE-FORMATTED stats message to the team's "Cowork report - ROI Advisors" Teams channel. Tables cover KPIs, time-by-category, value pillars, jobs-to-be-done, business processes, roles, skills, and deliverable types. Person names, file names and prompts are excluded; process/JTBD and customer/account names are kept. Bundles its own pipeline. Runs once or on a 15-day schedule (scheduled runs email the user to review/exclude sessions before posting).
  Use when the user asks to "post my Cowork ROI stats", "send my Cowork stats to the team channel", "run the Cowork ROI member step", or "share my Cowork impact with the team".
  Do NOT use for: the full personal HTML report (use cowork-roi-report), the manager-side team dashboard, GitHub Copilot reports, or single-meeting summaries.
cowork:
  category: productivity
  icon: PeopleTeam
---

# Cowork ROI — Member step (de-identified table post to the team channel)

Produces the **per-person, de-identified** input to a team Cowork ROI dashboard, rendered as
**HTML tables** so it's both readable in Teams and easy for a downstream Cowork task to parse.
**No person names, file names or prompts leave the machine** — the post carries aggregate totals,
task categories, value pillars, roles, skills, deliverable/IO breakdowns, and the de-duplicated
**Jobs-to-be-done** and **Work-by-business-process** tables (which may carry customer/account names —
those are in scope; only people's names are stripped).

## Prerequisites — none (self-contained)
This skill bundles its **own** analysis pipeline (`classify.py`, `compute.py`, the
`reconcile_taxonomy.py` memory step, taxonomy data, and the harvest references).
It does **not** depend on `cowork-roi-report` or any other skill being installed. A new user just
drops the single `cowork-roi-member/` folder into their Cowork skills directory
(`Documentos/Cowork/skills/`) and runs it — nothing else to install. It keeps a **per-user, durable
taxonomy memory** at `/mnt/user-config/.claude/cowork-process-registry.<userkey>.json` — scoped to
the invoking user (owner-stamped) and stored on their own mount (syncs to their OneDrive Cowork
folder). **There is NO bundled seed and nothing user-specific ships in the folder:** a first run
starts with no memory and mints the user's processes from their OWN sessions.

## When to use
- "Post my Cowork ROI stats to the team channel" / "run the Cowork ROI member step"
- A team cadence (e.g. every 15 days) where each member contributes their stats.

## When NOT to use
- Full personal HTML report with project detail → `cowork-roi-report`.
- Gathering everyone's posts into the team dashboard → the manager skill.

## Target channel (fixed)
- **Team:** ROI Advisors — `team_id = 71415fcb-e742-47e7-b5bc-9038eb02135e`
- **Channel:** "Cowork report - ROI Advisors" — `channel_id = 19:4GywFJZlqAFv_2v52oBX3dAmVKTZSzS82UZNvE9-rrM1@thread.tacv2`

Post with `PostChannelMessage(team_id=..., channel_id=..., body=<html>)`. (Fall back to
`team_name`/`channel_name` only if an ID call fails.)

All script paths below are under this skill's own folder:
`/mnt/user-config/.claude/skills/cowork-roi-member/scripts/`.

## Workflow

### 1. Choose run mode + period
Ask once with **`AskUserQuestion`**: *"Run this once, or automate it every 15 days?"* — options
**"Just once"** / **"Automate every 15 days (email me to review before each post)"**. The period
defaults to the **last 15 days** (ask only if the user names a different window). Window = N days
ago 00:00 → today 23:59, local time. If they choose automate, still produce a post now **and** set
up the schedule in step 9.

### 2. Resolve identity & dates
`GetMyDetails(select="mail,userPrincipalName,displayName,jobTitle")` (the `mail` is the per-user memory
owner — passed to `reconcile_taxonomy.py --owner` in step 5; `jobTitle` becomes the runner's **Role**
attribute shown on the post — see step 3). compute `after` = N days ago 00:00 local, `before` =
today 23:59 local, `window.label` = "Last N days", `window.months` = N/30.
**Role, not identity:** carry the directory `jobTitle` only. Never add country, and never any person
name, file name, or prompt.

### 3. Harvest the user's Cowork sessions (self-contained)
Cowork persists each session's workspace to OneDrive under a `Cowork` store (commonly
`Documents/Cowork/`, but often localized/suffixed — `Documentos/Cowork`, `Cowork 1`, …). Harvest
ALL session folders in the window:
- `GetDefaultDrive()` → personal OneDrive `drive_id`.
- **Locate the Cowork folder** — try `GetDriveChildren(drive_id, item_path="/Documents/Cowork")`; on
  404, list `/Documents` (then the drive root, then `/Documentos/Cowork`) and pick the child whose
  name starts with `Cowork` (case-insensitive). Carry the resolved name forward.
- **Enumerate all three layouts** under it, following pagination (`@odata.nextLink`) to exhaustion:
  Task folders `<Cowork>/Tasks/<goal-slug>-<YYYY-MM-DD>/` (→ `input/`+`output/`), root goal folders
  `<Cowork>/<goal-slug>-<YYYY-MM-DD>/`, and legacy `<Cowork>/sessions/<uuid>/`.
- **Scope to the Cowork app** — count a folder/artifact ONLY when its `createdBy.application.id` is
  the Cowork app id `6ab48b67-cd74-4ad4-81af-5932984589be`. **Never** enumerate `Documents/Apps/…`
  (a different product).
- Keep session folders whose created/modified date is in the window. For each, list its `output/`
  (and `input/`) for artifact names + extensions. **Fold supporting files** (QA screenshots,
  `-v2`/`-sample` variants, prompts, READMEs, lock files, zips) into the session's primary
  deliverable. Keep output-less (chat-only) sessions.
- Write `working/cowork_raw.json`:
  ```json
  { "meta": {"user":"<name>","email":"<mail>","role":"<jobTitle from step 2>","generated":"<YYYY-MM-DD>",
             "window":{"from":"...","to":"...","label":"Last N days","months":0.5},"hourly_rate":72},
    "sessions": [ {"id":"<slug>","date":"YYYY-MM-DD","hour":12,"goal":"<short verb-first phrase>",
                   "inputs":[{"name":"report.pdf","ext":"pdf"}],
                   "outputs":[{"name":"deck.pptx","ext":"pptx","skills":["Presentation Design"]}],
                   "skills":["Data Analysis"], "professional_roles":["Data Analyst"],
                   "has_folder":true, "exec_min":null} ] }
  ```
Do **not** classify/compute yet — the user prunes first.

### 4. Privacy opt-out — let the user remove any chat/task BEFORE anything is computed
**Mandatory, every run, before classify/compute.** Nothing about an excluded session is ever
classified, costed, named, or posted.
1. List the inventory: `python .../scripts/prune_sessions.py --in working/cowork_raw.json --list`
   (one numbered line per session, between `<<<COWORK-SESSION-INVENTORY>>>` markers).
2. **Interactive run:** ask which to leave out with an **`AskUserQuestion` card, `multiSelect: true`**
   — each option is one session (label = short goal + date). When you show the picker, include a short
   **reminder to exclude anything personal or non-work they're not comfortable sharing** with the team
   before it posts (each session's deliverables go out with it). `prune_sessions.py --list` prints this
   same reminder. `AskUserQuestion` allows 4 questions × 4 options (16 sessions) per call, so **page
   through ALL sessions** across consecutive rounds of 16 (30 → 2 rounds; tell the user "1 of 2") —
   every chat/task must be individually selectable; never show only a subset. Selecting nothing = keep
   everything.
3. **Scheduled run (no interactive user):** do **not** show the picker (it would hang). Compute the
   draft and **email the user to review/exclude in the task chat** (see step 9) — never post without
   the user's opt-out.
4. Apply: `python .../scripts/prune_sessions.py --in working/cowork_raw.json --drop "<indices>"`
   (or `--drop-ids "<ids>"`); confirm the remaining count.

### 5. Reconcile taxonomy against your PER-USER memory (writes working/process_overrides.json)
This skill keeps a **per-user, durable taxonomy memory** so process / JTBD names stay stable across
runs instead of being re-invented each time — **Process is the aggregation anchor** (align-first,
create-if-novel; the standalone Job layer was dropped). **The memory is specific to the invoking
user and never shared:**
- The registry is `/mnt/user-config/.claude/cowork-process-registry.<userkey>.json`, carrying an
  `owner` field. `<userkey>` is derived from the user's `mail` (from step 2); the file is on the
  user's own mount (syncs to their OneDrive Cowork folder).
- **First run = no memory.** There is NO bundled seed. `reconcile_taxonomy.py` also **ignores any
  registry whose `owner` isn't the invoking user** (a leaked/inherited/unstamped file), so a first
  run mints processes from the user's OWN sessions. Nothing user-specific ever ships in the folder.
- **Align:** `python /mnt/user-config/.claude/skills/cowork-roi-member/scripts/reconcile_taxonomy.py --in working/cowork_raw.json --owner "<signed-in user's mail>" --overrides working/process_overrides.json`
  For each **kept** session it (a) reuses a known **project**'s `{process, pillar, jtbd}`; else
  (b) aligns to an existing **process** by keyword similarity and registers a new project under it;
  else (c) mints a **new process** (flagged `"new"` — review/rename; on a first run every process is
  new, which is expected). It writes `working/process_overrides.json` and **persists the owner-stamped
  registry**. Run this **after** the privacy prune so excluded sessions never enter the registry.

`classify.py` then reads the overrides via `--overrides working/process_overrides.json`; without it,
it falls back to the bundled generic APQC taxonomy. `references/map-my-work-playbook.md` +
`value-pillars.md` document how to curate the registry / pillars.

### 6. Classify + compute (on the pruned set)
- `python /mnt/user-config/.claude/skills/cowork-roi-member/scripts/classify.py --in working/cowork_raw.json --out working/cowork_sessions.json --overrides working/process_overrides.json`
- `python /mnt/user-config/.claude/skills/cowork-roi-member/scripts/compute.py --in working/cowork_sessions.json --out working/cowork_roi_data.json`
- (If a credits ledger exists it is used automatically for the real-cost line; otherwise that line is omitted.)

### 7. Format the de-identified table message
```
python /mnt/user-config/.claude/skills/cowork-roi-member/scripts/format_member_message.py \
  --in working/cowork_roi_data.json --out working/member_message.html
```
The script prints the HTML body between `<<<COWORK-ROI-MEMBER-MESSAGE>>>` and `<<<END>>>` — use that
exact string as the message body. The header shows the period **and the runner's Role** (directory
`meta.role`; no country/name). Metric & section titles are kept **identical to the Copilot ROI Report
skill** (`cowork-roi-report/scripts/build_report.py`). The post is a sequence of **HTML `<table>`s**
(stable headers, one row per item) in this fixed order:
1. **Headline** — Metric · Value (Expert-equivalent hours +range, Professional-services value, Speed multiplier, Assisted hands-on hours, sessions, run tasks, deliverables, active days, hours/active day, real cost if measured).
2. **Where the time went — by task category** — Category · Band (low/typ/high) · Tasks · Hours · Value · % time.
3. **Business value pillars** — Pillar · Sessions · Hours · Value · % time.
4. **Jobs to be done** — Job to be done · Sessions · Hours · Value (de-duplicated `jtbd` from the durable registry via `reconcile_taxonomy.py`).
5. **Work by business process** — Process · Sessions · Hours · Value · % time (Process is the taxonomy anchor).
6. **Roles Cowork assembled for me** — Role · Hours · Value.
7. **Skills applied** — Skill · Deliverables · Sessions · Value.
8. **Analyzed → Produced** — Measure · Value, plus **Inputs by type** and **Outputs by type**.
9. **Deliverables & the skills behind them** — every deliverable made visible and **labelled with the business process it supported**: Type · Date · Business process · Skills · Hours · Value (de-identified — no file names), followed by a **By type** rollup (Deliverable type · Count · Hours · Value · Skills used).
10. **Activity by day** — Date · Run tasks.

Every value comes from `cowork_roi_data.json`; no hand math.

### 8. Show + post
Show the user the rendered tables inline, then post:
`PostChannelMessage(team_id="71415fcb-e742-47e7-b5bc-9038eb02135e", channel_id="19:4GywFJZlqAFv_2v52oBX3dAmVKTZSzS82UZNvE9-rrM1@thread.tacv2", subject="Cowork ROI — <window label>", body=<the HTML body>)`.
The platform shows its own approval dialog before anything sends.

### 9. Automate (only if the user chose it in step 1)
`SetupScheduledPrompt` (frequency **Day**, interval **15**, hours `["8"]`, name "Cowork ROI member
(every 15 days)") with a **self-contained** description:
> "Generate my Cowork ROI stats for the last 15 days: harvest my Cowork sessions, compute the
>  table-formatted de-identified post, then EMAIL me that it's ready and ask me to open this task's
>  chat to exclude any sessions I don't want shared before it posts to the Cowork report - ROI
>  Advisors channel. Do not post until I've reviewed."

**On each scheduled execution (no user present):** harvest → map-my-work → compute a draft, then
`SendEmailWithAttachments(to=[<user's own email>], subject="Your Cowork ROI post is ready to review",
body="<headline summary + the session inventory list>")` telling them to open **this task's chat** to
run the opt-out picker and post. **Never auto-post on a scheduled run** — the user always does the
final opt-out + post interactively in the task chat. Confirm setup in plain language.

## Guardrails
- **De-identified, not fully anonymized.** Never include any person's name, raw file names, prompt
  text, or **country**. The post DOES carry the runner's directory **Role** (job title — a
  de-identified attribute many people share), and the Jobs-to-be-done and business-process tables —
  including any **customer/account names** their text contains. Do not scrub customer names from
  process/JTBD strings.
- **Grouped business processes.** The "Work by business process" table shows a short canonical set
  (see `scripts/process_groups.json`); the underlying per-user registry and Jobs-to-be-done stay
  granular. This grouping + the skills vocabulary + the Role attribute are a **shared data contract** —
  they must match `cowork-roi-report`'s copies (the aggregated "Cowork report – ROI Advisors" reader
  reuses those). Change them in both bundles together.
- **Fixed channel.** Always post to the ROI Advisors channel above unless the user names another.
- **Conservative numbers.** All metrics come from the bundled pipeline — no hand math, no fabricated
  figures. If a section is empty, omit it rather than inventing.
- **Privacy opt-out is mandatory.** Always run step 4 before computing/posting. On interactive runs
  show the picker; on scheduled runs email the user to review in the task chat. Excluded sessions are
  dropped from `cowork_raw.json` so they are never classified, costed, named, or sent.
- **Scheduled runs never auto-post.** A scheduled execution emails the user and stops; posting only
  happens after the user's interactive opt-out. The platform approval dialog is the final gate.
- **One post per run.** Re-running replaces the user's contribution; the manager skill keeps the latest per sender.
- **Per-user memory — never leak it.** The taxonomy registry is owner-scoped and owner-stamped;
  `reconcile_taxonomy.py` ignores any file that isn't the invoking user's, and a first run starts
  empty. NEVER bundle the registry, any `cowork-process-registry*.json`, or a populated
  `process_overrides.json` when packaging/sharing this skill — overrides ship as `{}` and are written
  under `working/` at runtime. (A prior version shipped a personal seed + populated overrides, which
  leaked one user's jobs/processes into everyone who ran the package — that is the fatal flaw this
  guard prevents.)

## Bundled files (self-contained)
- `scripts/prune_sessions.py` — lists the session inventory + applies the privacy opt-out.
- `scripts/format_member_message.py` — renders `cowork_roi_data.json` into the de-identified HTML table post.
- `scripts/reconcile_taxonomy.py` — aligns each kept session to the invoking user's **owner-scoped** registry (align-first, create-if-novel; ignores any file that isn't theirs); writes `working/process_overrides.json` + persists the owner-stamped registry. Takes `--owner`. Reuses `classify.py`'s matcher.
- `scripts/classify.py` — ext→category classifier; applies per-run overrides via `--overrides working/process_overrides.json`, then groups the process label via `process_groups.json`. Reads `apqc_taxonomy.json`, `roles_taxonomy.json`, `process_groups.json`.
- `scripts/compute.py` — research-anchored two-clock model → `cowork_roi_data.json` (incl. `pct_time`).
- `scripts/apqc_taxonomy.json`, `scripts/roles_taxonomy.json`, `scripts/skills_vocabulary.json` — taxonomy/vocabulary data (`skills_vocabulary.json` is the curated ~30-skill canonical set).
- `scripts/process_groups.json` — canonical business-process **grouping** map (APQC labels + registry/override names → one short set); applied by `classify.py`. Shared with `cowork-roi-report`.
- `scripts/process_overrides.json` (ships empty `{}`, vestigial) + `scripts/process_overrides.example.json` (format example). The real per-run overrides live at `working/process_overrides.json` — never in the bundle.
- **No seed ships.** The per-user registry lives at `/mnt/user-config/.claude/cowork-process-registry.<userkey>.json` (owner-stamped) and is created on first run from the user's own sessions.
- `references/map-my-work-playbook.md`, `references/value-pillars.md` — how to curate the registry / value pillars.
