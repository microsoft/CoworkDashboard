#!/usr/bin/env python3
"""
build_outputs.py — ONE build step for the team rollup: renders the local dashboard site
from a single team_data.json.

The interpretation guide is now FOLDED INTO the dashboard itself — the "How to read" tab plus a
clickable "?" helper on every section title — so the standalone one-page PDF is no longer built or
shared by default. Recipients had been missing the separate attachment and toggling between two
files; keeping the guide inside the dashboard removes that friction.

The legacy one-page PDF guide (build_guide_pdf.py) is still available for anyone who wants a
printable copy: pass --with-pdf to regenerate it. It is NOT part of the default flow.

Emailing the verified self-contained HTML report requires separate explicit approval. The localhost
URL is never emailed to teammates. Before returning success, this build runs
verify_dashboard.py on both the local site and attachment, failing if required visuals, controls, or
de-identified data contract are missing.

Usage:
  python build_outputs.py --in working/team_data.json \
         [--config config/team_config.json] \
         [--out-html output/team-dashboard/index.html] \
         [--with-pdf [--out-pdf output/how-to-read-team-roi-dashboard.pdf]]
"""
import argparse, os, sys
from types import SimpleNamespace

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_dashboard          # noqa: E402
import verify_dashboard          # noqa: E402


def main(a):
    d = os.path.dirname(a.out_html)
    if d:
        os.makedirs(d, exist_ok=True)
    lock = os.path.join(d or ".", ".dashboard-build.lock")
    try:
        os.mkdir(lock)
    except FileExistsError:
        raise SystemExit(
            "[build_outputs] another build is active. Retry after it finishes. "
            f"If a previous build crashed, confirm it has stopped before removing {lock}."
        )
    try:
        build(a)
    finally:
        os.rmdir(lock)


def build(a):
    # HTML dashboard — the interpretation guide is built into it (the "How to read" tab).
    build_dashboard.main(SimpleNamespace(inp=a.inp, out=a.out_html))
    verify_dashboard.main(SimpleNamespace(inp=a.out_html))
    attachment = os.path.join(os.path.dirname(a.out_html), "team-dashboard-report.html")
    verify_dashboard.main(SimpleNamespace(inp=attachment))
    if getattr(a, "with_pdf", False):
        import build_guide_pdf   # optional (reportlab) — only imported when explicitly requested
        dp = os.path.dirname(a.out_pdf)
        if dp:
            os.makedirs(dp, exist_ok=True)
        build_guide_pdf.main(SimpleNamespace(out=a.out_pdf, data=a.inp, config=a.config))
        print(f"[build_outputs] built dashboard + optional legacy PDF guide → {a.out_html} + {a.out_pdf}")
    else:
        print(f"[build_outputs] built verified report attachment → {attachment}; confirm recipient before email")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", default="working/team_data.json")
    ap.add_argument("--config", default="config/team_config.json")
    ap.add_argument("--out-html", dest="out_html", default="output/team-dashboard/index.html")
    ap.add_argument("--with-pdf", dest="with_pdf", action="store_true",
                    help="Also regenerate the legacy one-page PDF guide (off by default; the guide is now in-dashboard)")
    ap.add_argument("--out-pdf", dest="out_pdf", default="output/how-to-read-team-roi-dashboard.pdf")
    main(ap.parse_args())
